// connect to server.js
var server = require("../../../nodejs/server.js");
server.start();