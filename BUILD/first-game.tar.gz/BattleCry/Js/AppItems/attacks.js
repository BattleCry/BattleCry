var attacks = {
	warrior : {
		main : [{
			id: 1,
			attackName: 'Wild Slash',
			html: '<img src="img/Attacks/Warrior/Slash.png" height="70px" width="70px">',
		},{
			id: 2,
			attackName: 'Viral Reaper',
			html: '<img src="img/Attacks/Warrior/Lightning.png" height="70px" width="70px">',
		},{
			id: 3,
			attackName: 'Infernal Bane Star',
			html: '<img src="img/Attacks/Warrior/Plasma.jpg" height="70px" width="70px">',
		},],
	},
};