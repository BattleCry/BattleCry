var server = require("../../nodejs/server2.js");
server.start();