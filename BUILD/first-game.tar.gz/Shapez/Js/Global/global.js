var global = {
	session : {},

	saves : [],
};