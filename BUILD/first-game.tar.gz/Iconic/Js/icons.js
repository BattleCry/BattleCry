var icons = [{
	preview : '<div style="position: absolute;  border-radius: 1000px; height: 60px; width: 60px; background-color: black; left: 5px; top: 5px"><div style="position: absolute;  border-radius: 1000px; height: 40px; width: 40px; background-color: white; left: 10px; top: 10px"></div></div><div style="position: absolute;  border-radius: 1px; height: 55px; width: 10px; background-color: black; left: 70px; top: 43px; -webkit-transform: rotate(135deg); border-radius: 3px"></div>',
	html 	: '<div style="position: absolute;  border-radius: 1000px; height: 60px; width: 60px; background-color: black; left: 5px; top: 5px"><div style="position: absolute;  border-radius: 1000px; height: 40px; width: 40px; background-color: white; left: 10px; top: 10px"></div></div><div style="position: absolute;  border-radius: 1px; height: 55px; width: 10px; background-color: black; left: 70px; top: 43px; -webkit-transform: rotate(135deg); border-radius: 3px"></div>',
	name 	: ''
},{
	preview : '<div style="position: absolute; right: 0px; left: 0px; top: 0px; bottom: 0px; background-color: black"></div><div style="position: absolute; right: 0px; top: 0px; background-color: black; border: 10px solid white; border-right: 10px solid black; border-bottom: 10px solid black; left: 0px; width: 0px"></div><div style="position: absolute; right: 0px; top: 0px; background-color: black; border: 10px solid white; border-bottom: 10px solid black; border-left: 10px solid black; right: 0px; width: 0px"></div><div style="position: absolute; bottom: 0px; left: 0px; border: 10px solid white; border-top: 10px solid black; border-right: 10px solid black"></div><div style="position: absolute; bottom: 0px; right: 0px; border: 10px solid white; border-left: 10px solid black; border-top: 10px solid black"></div>',
	html 	: '<div style="position: absolute; right: 0px; left: 0px; top: 0px; bottom: 0px; background-color: black"></div><div style="position: absolute; right: 0px; top: 0px; background-color: black; border: 10px solid white; border-right: 10px solid black; border-bottom: 10px solid black; left: 0px; width: 0px"></div><div style="position: absolute; right: 0px; top: 0px; background-color: black; border: 10px solid white; border-bottom: 10px solid black; border-left: 10px solid black; right: 0px; width: 0px"></div><div style="position: absolute; bottom: 0px; left: 0px; border: 10px solid white; border-top: 10px solid black; border-right: 10px solid black"></div><div style="position: absolute; bottom: 0px; right: 0px; border: 10px solid white; border-left: 10px solid black; border-top: 10px solid black"></div>',
	name 	: ''
}];

/*
,{
	preview : '',
	html 	: '',
	name 	: ''
}
*/